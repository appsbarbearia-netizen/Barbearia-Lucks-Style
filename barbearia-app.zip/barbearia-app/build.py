#!/usr/bin/env python3
"""Gera o app PWA de um cliente.
Uso:  python3 build.py clientes/NOME_DO_CLIENTE
Lê:   clientes/NOME/config.json, logo.png (quadrada, ideal 512px+), fotos/ e (opcional) og.jpg
Gera: dist/NOME/ pronto para publicar.
"""
import json, os, re, shutil, sys, urllib.parse
from PIL import Image, ImageColor

RAIZ = os.path.dirname(os.path.abspath(__file__))
OBRIGATORIOS = ["slug", "nome", "whatsapp", "whatsapp_exibicao", "instagram", "rua", "cidade", "estado", "servicos", "vitrine", "galeria"]

def erro(msg): sys.exit("ERRO: " + msg)
def esc(s): return (s.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;"))
def rgb(hexa): r, g, b = ImageColor.getrgb(hexa); return f"{r},{g},{b}"

def main():
    if len(sys.argv) != 2: erro(__doc__)
    pasta = os.path.abspath(sys.argv[1])
    cfg_path = os.path.join(pasta, "config.json")
    if not os.path.isfile(cfg_path): erro("config.json não encontrado em " + pasta)
    c = json.load(open(cfg_path, encoding="utf-8"))
    faltam = [k for k in OBRIGATORIOS if not c.get(k)]
    if faltam: erro("faltam campos no config.json: " + ", ".join(faltam))
    if not re.fullmatch(r"[a-z0-9-]+", c["slug"]): erro("slug só aceita letras minúsculas, números e hífen")
    if not re.fullmatch(r"\d{12,13}", c["whatsapp"]): erro("whatsapp deve ter só números: 55 + DDD + número")

    logo = os.path.join(pasta, "logo.png")
    if not os.path.isfile(logo): erro("logo.png não encontrada em " + pasta)
    fotos = os.path.join(pasta, "fotos")
    usadas = {f["arquivo"] for f in c["vitrine"]} | {g["arquivo"] for g in c["galeria"]}
    ausentes = sorted(a for a in usadas if not os.path.isfile(os.path.join(fotos, a)))
    if ausentes: erro("fotos que estão no config mas não na pasta fotos/: " + ", ".join(ausentes))

    cor = {"fundo": "#090909", "painel": "#151515", "painel2": "#1d1b16", "destaque": "#d6ad52",
           "destaque_claro": "#f2d88f", "texto": "#f7f4ed", "texto_suave": "#a8a39a"}
    cor.update(c.get("cores", {}))
    hero = c.get("hero", {})
    tipo = c.get("tipo_negocio", "Barbearia")
    slogan = c.get("slogan", "Barbearia Premium")
    bairro = c.get("bairro", "")
    nome = c["nome"]
    endereco = c["rua"] + (" — " + bairro if bairro else "")
    consulta = urllib.parse.quote_plus(f'{c["rua"]} {bairro} {c["cidade"]}'.strip())
    mapa = c.get("mapa_url") or f"https://www.google.com/maps/search/?api=1&query={consulta}"
    descricao_curta = c.get("descricao_curta") or f"Veja nossos trabalhos e agende seu horário na {nome}."
    descricao = c.get("descricao") or f"{nome}, {tipo.lower()}{' na ' + bairro if bairro else ''}. Veja nossos trabalhos e agende seu horário pelo WhatsApp."
    site = c.get("site_url", "").strip()
    if site and not site.endswith("/"): site += "/"

    config_js = {
        "nome": nome, "whatsapp": c["whatsapp"], "whatsappExibicao": c["whatsapp_exibicao"],
        "instagram": c["instagram"], "endereco": endereco, "mapaUrl": mapa,
        "horarioFuncionamento": c.get("horario_funcionamento", ""),
        "diasFechados": c.get("dias_fechados", []),
        "horarios": c.get("horarios", ["09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00"]),
        "servicos": c["servicos"], "regras": c.get("regras", []),
        "horariosPorDia": c.get("horarios_por_dia", {}), "mostrarPrecos": c.get("mostrar_precos", False),
        "vitrine": [{"src": "fotos/" + f["arquivo"], "alt": f.get("alt", "Trabalho de " + nome)} for f in c["vitrine"]],
        "galeria": [f'fotos/{g["arquivo"]}|{g.get("titulo", "")}' for g in c["galeria"]],
    }
    json_ld = {"@context": "https://schema.org", "@type": "HairSalon", "name": nome,
               "description": f"{tipo}: cortes, barba e sobrancelha.", "telephone": "+" + c["whatsapp"],
               "address": {"@type": "PostalAddress", "streetAddress": c["rua"], "addressLocality": c["cidade"],
                           "addressRegion": c["estado"], "addressCountry": "BR"},
               "sameAs": ["https://instagram.com/" + c["instagram"]]}
    og_tags = ""
    if site:
        og_tags = (f'<meta property="og:image" content="{site}og.jpg">\n'
                   f'<meta property="og:url" content="{site}">\n'
                   f'<meta name="twitter:image" content="{site}og.jpg">')

    def seguro_js(o): return json.dumps(o, ensure_ascii=False, indent=2).replace("</", "<\\/")
    valores = {
        "NOME": esc(nome), "NOME_MAIUSC": esc(nome.upper()), "NOME_CURTO": esc(c.get("nome_curto", nome)[:12]),
        "SLUG": c["slug"], "SLOGAN": esc(slogan), "SLOGAN_PEQUENO": esc(c.get("slogan_pequeno", tipo + " premium")),
        "DESCRICAO": esc(descricao), "DESCRICAO_CURTA": esc(descricao_curta),
        "HERO_EYEBROW": esc(f"{tipo} • {bairro}" if bairro else tipo),
        "HERO_TITULO": hero.get("titulo", "Seu estilo.<br>Nosso trabalho."),
        "HERO_TEXTO": hero.get("texto", f"Veja alguns dos nossos trabalhos e escolha seu próximo visual."),
        "INSTAGRAM": c["instagram"], "WHATSAPP": c["whatsapp"], "WHATSAPP_EXIBICAO": esc(c["whatsapp_exibicao"]),
        "COR_BG": cor["fundo"], "COR_PANEL": cor["painel"], "COR_PANEL2": cor["painel2"],
        "COR_DESTAQUE": cor["destaque"], "COR_DESTAQUE_CLARO": cor["destaque_claro"],
        "COR_TEXTO": cor["texto"], "COR_MUTED": cor["texto_suave"],
        "RGB_BG": rgb(cor["fundo"]), "RGB_GOLD": rgb(cor["destaque"]),
        "OG_IMAGE_TAGS": og_tags, "JSON_LD": json.dumps(json_ld, ensure_ascii=False).replace("</", "<\\/"),
        "CONFIG_JS": seguro_js(config_js),
    }

    saida = os.path.join(RAIZ, "dist", c["slug"])
    shutil.rmtree(saida, ignore_errors=True)
    os.makedirs(saida)
    for arq in ("index.html", "manifest.webmanifest", "sw.js"):
        txt = open(os.path.join(RAIZ, "modelo", arq), encoding="utf-8").read()
        txt = re.sub(r"\{\{([A-Z0-9_]+)\}\}", lambda m: valores[m.group(1)], txt)
        sobras = re.findall(r"\{\{[A-Z0-9_]+\}\}", txt)
        if sobras: erro(f"placeholders sem valor em {arq}: {sobras}")
        open(os.path.join(saida, arq), "w", encoding="utf-8").write(txt)
    shutil.copytree(fotos, os.path.join(saida, "fotos"))

    # ícones a partir da logo
    im = Image.open(logo).convert("RGBA")
    if im.width != im.height: print("AVISO: logo.png não é quadrada; será ajustada no centro.")
    lado = min(im.size)
    im = im.crop(((im.width - lado) // 2, (im.height - lado) // 2, (im.width + lado) // 2, (im.height + lado) // 2))
    for nome_arq, tam in (("icon-192.png", 192), ("icon-512.png", 512)):
        im.resize((tam, tam), Image.LANCZOS).save(os.path.join(saida, nome_arq))
    ios = Image.new("RGB", (180, 180), ImageColor.getrgb(cor["fundo"]))   # iOS não aceita transparência
    ico = im.resize((180, 180), Image.LANCZOS); ios.paste(ico, (0, 0), ico)
    ios.save(os.path.join(saida, "apple-touch-icon.png"))
    im.resize((48, 48), Image.LANCZOS).save(os.path.join(saida, "favicon.ico"), sizes=[(16, 16), (32, 32), (48, 48)])
    mask = Image.new("RGBA", (512, 512), ImageColor.getrgb(cor["fundo"]) + (255,))   # área segura: logo a 70%
    mask.paste(im.resize((358, 358), Image.LANCZOS), (77, 77), im.resize((358, 358), Image.LANCZOS))
    mask.convert("RGB").save(os.path.join(saida, "icon-maskable-512.png"))

    # imagem de compartilhamento
    og = os.path.join(pasta, "og.jpg")
    if os.path.isfile(og): shutil.copy(og, os.path.join(saida, "og.jpg"))
    else:
        fundo = Image.new("RGB", (1200, 630), ImageColor.getrgb(cor["fundo"]))
        fundo.paste(im.resize((480, 480), Image.LANCZOS), (360, 75), im.resize((480, 480), Image.LANCZOS))
        fundo.save(os.path.join(saida, "og.jpg"), quality=90)
    print("OK ->", saida)
    if not site: print("AVISO: site_url vazio; og:image não incluída. Preencha depois de publicar.")

main()
