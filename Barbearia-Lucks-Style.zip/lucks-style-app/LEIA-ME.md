# Barbearia Luck's Style — app

App de barbearia (preto e dourado) feito com TanStack Start + React + Tailwind v4.

## Como rodar no seu computador

1. Instale o [Bun](https://bun.sh) (ou use npm).
2. Na pasta do projeto:
   - `bun install`  (ou `npm install`)
   - `bun run dev`  (ou `npm run dev`)
3. Abra o endereço que aparecer no terminal (geralmente http://localhost:8080).

## Colocar no ar

- `bun run build` gera a pasta `dist/`.
- O projeto está preparado para Cloudflare Workers (`dist/server/wrangler.json`).
  Dá para publicar com `npx wrangler deploy` ou em qualquer hospedagem Node/Edge.

## Trocar os dados do cliente (para revender)

- Textos, preços, equipe, horários, WhatsApp, endereço e fotos: **`src/config/barbearia.ts`**.
- Fotos: coloque os arquivos em **`public/lucks/`** com os mesmos nomes e atualize
  o campo `url` em **`src/assets/lucks/*.asset.json`**.
- Regras de horário e geração de horários da agenda: **`src/lib/agenda.ts`**
  (testes em `src/lib/agenda.test.ts`, rode com `bun run test`).
- Nome do app e ícones: **`public/manifest.webmanifest`** e `public/icon-*.png`.

## Telas

- `/` Início — capa, serviços, equipe, horários
- `/agendar` — escolha de dia, horário e envio do pedido pelo WhatsApp
- `/galeria` — fotos dos cortes

## Subir para o GitHub

A pasta já é um projeto completo: `git init`, `git add .`, `git commit -m "app"` e
`git push` para um repositório vazio. O `.gitignore` deixa de fora `node_modules` e `dist`.
